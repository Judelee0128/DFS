
function DFSmask=heatmap_DFS(DFS,resdir,n,minValue,maxValue)
fig = figure('Position', [0 0 1200 200]);
%[r_i, c_i] = ind2sub([n n], i_mask);
i_condition=size(DFS,2)
 for ii=1:i_condition
    %n = 99;  
   mask   = triu(ones(n, n), 1);
   i_mask = find(mask);
   l_mask = length(i_mask);
    mask(i_mask)=DFS(:,ii);
    mask=[mask+mask'];
    subplot(1,i_condition,ii);
    DFSmask{ii}=mask;
    h=heatmap(mask);
    colormap(flipud(brewermap([],'RdBu')));
    caxis([minValue maxValue]); 
    clear mask
 end
cd(resdir)
return

