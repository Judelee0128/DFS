most of the functions are from Favaretto et al. (2022), thanks to them!
1."eval_LEs_DFC_OPS.m"---to orgnize data 
2."main_DFSs.m"---to get indics of DFS, including stata ratio, dwelling time, and transition probability
3. "Get_all_state_index.m"---to orgnize DFS indics for further statistical analysis
4. "Q_RM_LM.m"---to calculate the Q value between the cerebrum and the cerebellum
5."Shift_Hubs_lhh.m"---to obtain hubs. However, before this code, please run gretna manually to get network indice, including Degree Centrality, Betweenness Centrality,Nodal Efficiency.