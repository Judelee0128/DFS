% this script is used to detect hubs
% Junjie Wu
% 2022-04-10
%
function Shift_Hubs_lhh(ROIname,datadir)
%clc; clear; close all
%% setting
HubIndice = {'DegreeCentrality','BetweennessCentrality','NodalEfficiency';
    'aDc','aBc','aNe'; 'Dc','Bc','Ne'};

%Folders = {'A1_Net_rest',...
  %  'A1_Net_task1Stim','A1_Net_task2Stim','A1_Net_task3Stim',...
     %'A1_Net_another1','A1_Net_another2','A1_Net_another3','A1_Net_another4'};
 Folders = {'DFS1','DFS2','DFS3'};   
%states = cellfun(@(x) x(8:end), Folders,'Unif',0);
states = cellfun(@(x) x(1:end), Folders,'Unif',0);
%datadir='I:\03_Results\Project_I\task2\OPS_DFS\Results_mean_OPS\Results\';
output = [datadir,'Shift_Hubs_lhh\']; mkdir(output)
Sparsities = 0.27:0.01:0.5;
%% load data
% node labels
%[~,~,ROIcerebrum] = xlsread(fullfile('A0_BOLD_OPS_rest','ROI_activation_result.xlsx'),'cerebrum');
%ROIcerebrum = ROIcerebrum(3:50,13)';
%[~,~,ROIcerebellum] = xlsread(fullfile('A0_BOLD_OPS_rest','ROI_activation_result.xlsx'),'cerebellum');
%ROIcerebellum = ROIcerebellum(3:14,11)';
%ROIcerebellum = cellfun(@(x) ['\color{blue} ',x], ROIcerebellum,'Unif',0);
%Lname = [ROIcerebrum,ROIcerebellum];
%Lname = cellfun(@(x) strrep(x,'_','\_'),Lname,'Unif',0);
%dROI='I:\03_Results\Project_I\task2\OPS_DFS\a01_input_ROIs\ROIs_Final\';
%d=dir([dROI,'*.nii']);
%ROIname={d.name}';
%ROInum=length(ROIname);
%ROI_RM=1:34;
%ROI_LM=35:42;
%ROIlabel=ones(42,1);
%ROIlabel(35:42)=2;
%[NUM,TXT,RAW]=xlsread('I:\03_Results\Project_I\task2\OPS_DFS\a01_input_ROIs\a02_making_ROIs.xlsx');
%[NUM,TXT,RAW]=xlsread(dROIfile);
%ROIcoord=NUM(:,1:3);
%ROIname=TXT(2:end,9);

%% rank and plot
i_index = 1;
%close all
nNet = length(Folders);
for i_folder = 1: nNet
    Folder =[datadir, Folders{i_folder}];
    Data_mean_all = []; Data_sd_all = []; hubs = [];
    for i_index = 1:3
        load(fullfile(Folder,'Gretna',HubIndice{1,i_index},[HubIndice{1,i_index},'.mat']));
        Data = eval(HubIndice{2,i_index});
        Data_mean = mean(Data,1)';
        Data_sd = std(Data,0,1)';
        Data_mean_all = [Data_mean_all, Data_mean];
        Data_sd_all = [Data_sd_all, Data_sd];
        
        [~,order] = sort(Data_mean,'descend');
        hubs{i_index} = order(1:round(length(order)*0.1)); % Top 10%
        %hubs{i_index} = find(Data_mean > (mean(Data_mean) + std(Data_mean))); % Top 1SD
    end
    N = length(order);
    hubs_bin = zeros(N,3);
    for i_index = 1:3
        hubs_bin(hubs{i_index},i_index) = 1;
    end
    hubs = find(sum(hubs_bin,2)>=2);
%     hubs = intersect(intersect(hubs{1},hubs{2}),hubs{3});
    %labels = ROIname(hubs')';
    %labels = ROIname(hubs);
    labels = ROIname{hubs};
   % hubmat = fullfile(output,['hubs_',Folder(8:end), '.mat']);
    %save(hubmat,'hubs','labels')
    Lname=ROIname;
    Lab = Lname;
    for h = 1:length(hubs)
        Lab{hubs(h)} = ['\bf{',Lname{hubs(h)},'}'];
    end
    Data_mean_all = zscore(Data_mean_all,1);
    Data_mean_all = Data_mean_all - repmat(min(Data_mean_all),[N,1]) + 0.5;
    [~,order] = sort(mean(Data_mean_all,2),'descend');
    %     [~,order] = sort(Data_mean_all(:,3),'descend');
    order =  order([find(ismember(order,hubs)); find(~ismember(order,hubs))]);
    Data_mean_all = Data_mean_all(order,:);
    subplot(1,nNet,i_folder)
    bar(Data_mean_all)
    set(gca, 'Xlim', [0 N+1], 'fontsize', -0.07*N+12.67,'FontName', 'arial',...
        'box', 'off','XTICK', 1:N, 'XTickLabel', Lab(order),'ticklength',[0.005 0.05],...
        'Ylim',[0,7],'YTick',[0:3:7]);
    view(90,90)
    set(gca,'YaxisLocation','right');
    text(-2,1.5,states{i_folder})
    
end
set(gcf,'position',[100,0,2500,1000])
set(gcf,'color','white')

legend(HubIndice{1,1},HubIndice{1,2},HubIndice{1,3},'Position',[720,730,0,0])
legend('boxoff');

end
