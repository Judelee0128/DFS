%get modularity  DANDMN homotopic_dyn


function [sub,stateall]=Get_all_state_index(Time_ctr_pat_bold,DFS_sw,n_Subjects,K)

suball=sum(n_Subjects(1:4));
[LEigs_time_OPS] = split_LEigs_subj(DFS_sw', Time_ctr_pat_bold, n_Subjects);

    %% caculate each index in each participant
 for ii=1:suball
       sub_state=LEigs_time_OPS(1,:,ii);
       kk=unique(sub_state);
       % dwelling time
       lifespan = evaluate_dwelltime(sub_state, K);
       mean_lifespan=zeros(1,K);
       for i = 1:length(kk)
         data = lifespan{kk(i)};
         mean_lifespan(kk(i)) = mean(data(:));
       end
       sub.lifespan(ii,:)=mean_lifespan;
       %% jumps
       [DFS_trans, idx_trans, DFS_trans_v2]=evaluate_DFS_transition_noDiagonal(sub_state, K)
       DFS_trans_tmp=reshape(DFS_trans,1,K*K);
       sub.DFS_trans(ii,:)=DFS_trans_tmp;
       %% fraction
       counts = histcounts(sub_state, 1:K+1); 
       ratios = counts/length(sub_state);
       sub.state(ii,:)=ratios;
 end
 stateall=sub;
return

