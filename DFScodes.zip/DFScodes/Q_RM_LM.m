%clear all;
%in = 'A4_Shift_Hubs_Modules';
%out = fullfile('A4_CerebullarRate'); mkdir(out)
%Folders = {'A1_Net_rest',...
  %  'A1_Net_task1Stim','A1_Net_task2Stim','A1_Net_task3Stim',...
  %  'A1_Net_another1','A1_Net_another2','A1_Net_another3','A1_Net_another4'};

% rate_colomn = 1; % intra-cerebrum
% rate_colomn = 2; % intra-cerebellum
%rate_colomn = 3; % between cerebrum and cerebellum
% rate_colomn = 4; % Q
function [Rate_all_states,random_level]=Q_RM_LM(DFS,Sparsities)
%states = cellfun(@(x) x(8:end), Folders,'Unif',0); % get the names of states
states={'DFS1','DFS2','DFS3'};

%Sparsities = 0.27:0.01:0.5; % set sparsities 
%% count connections
% labels and numbers of ROIs in cerebrum and cerebellum

node_c1 = 1:34; % cerebrum
node_c2 = 35:42; % cerebellum

node=42;

Ci = ones(node,1);
Ci(node_c2,1) = Ci(node_c2,1) + 1; % nodes in cerebellum

net = zeros(node); % setting up a network of 99 x 99
net_c1 = net;
net_c1(node_c1,node_c1) = ones(length(node_c1)); % connections in cerebrum
loc_c1 = find(tril(net_c1,-1)); % locations of connections in cerebrum
net_c2 = net;
net_c2(node_c2,node_c2) = ones(length(node_c2)); % connections in cerebellum
loc_c2 = find(tril(net_c2,-1)); % locations of connections in cerebellum
net_c1c2 = net;
net_c1c2(node_c1,node_c2) = ones(length(node_c1),length(node_c2)); % connections between cerebrum and cerebellum
net_c1c2(node_c2,node_c1) = ones(length(node_c2),length(node_c1));
loc_c1c2 = find(tril(net_c1c2,-1)); % locations of connections between cerebrum and cerebellum

%
Rate_all_states = {[''],'WithinCerebrum','WithinCerebellum','CrossCC','Q'}; % make a bag to contain results
Rate_states_subj_sparsities = {}; % make a bag to contain cerebo-cerebullar rates of each subject and each sparsity
Rate_states_subj = {}; % make a bag to contain cerebo-cerebullar rates of each subject with sparsities integraged  

%for i_folder = 1 %:length(Folders) % run for each state
   % Folder = Folders{i_folder};
    %load(fullfile(Folder,'FCMatrixZ_all','zGroupAll.mat')); % load individual data
    
    %W_all = DFC_bold;
    W_all = DFS;
  
    n=42;
    Rate_subj_sparsities = [];
    for i_subj = 1:size(W_all,2) % run for each subject
        %W = W_all(:,i_subj);
          mask   = triu(ones(n, n), 1);
          i_mask = find(mask);
          l_mask = length(i_mask);
          mask(i_mask)=W_all(:,i_subj);
          mask=[mask+mask'];
          W=mask;
        
        
        %W1=reshape(W,42,42);
        conn_locs = tril(reshape(1:length(W(:)),size(W)),-1); % get the location of each connections in the matrix
        conn_locs = conn_locs(conn_locs>0);
        conn_strengths = W(conn_locs); % get the density of all connections
        conn_strengths = sort(conn_strengths,'descend');
        
        i_sp = 1;
        for i_sp = 1:length(Sparsities) % run for each sparsity
            cutoff_sp = Sparsities(i_sp);
            
            top_position = round(length(conn_strengths)*cutoff_sp,0);
            cutoff_conn = conn_strengths(top_position); % get the connection strength of the cutoff
            
            w = W > cutoff_conn; % get a binary network
            w = double(w); 
            conns_all = sum(sum(tril(w,-1))); % all connections
            conns_c1 = sum(w(loc_c1)); % connections in the cerebrum
            conns_c2 = sum(w(loc_c2)); % connections in the cerebellum
            conns_c1c2 = sum(w(loc_c1c2)); % connections across cerebellum and cerebrum
            
            q = modularity_und_Q(w,Ci);  % compute modularity of cerebo-cerebellar network
            
            rate = [[conns_c1,conns_c2,conns_c1c2]./conns_all,q]; % collect data
            Rates_sparsities(i_sp,:) = rate;
            Rate_subj_sparsities(i_subj,:,i_sp) = rate;
            %Rate_subj_sparsities(i_subj,i_sp) = rate;
        end
        Rate_subj_tmp = cumtrapz(Rates_sparsities); % integrate all sparsities
       % Rate_subj(i_subj,:) = Rate_subj_tmp(end,:); % get the all
        Rate_subj(1,:) = Rate_subj_tmp(end,:); % get the all
       % Rate_subj(:,1:3) = Rate_subj(:,1:3)./repmat(sum(Rate_subj(:,1:3),2),[1,3]); % re-calculatethe rate accordig to the interageted values
     Rate_subj(1,1:3) = Rate_subj(1,1:3)./repmat(sum(Rate_subj(1,1:3),2),[1,3]);
        i_folder=i_subj;
    Rate_states_subj_sparsities(i_folder,1) = states(i_folder); % each state
    Rate_states_subj_sparsities(i_folder,2) = {Rate_subj_sparsities}; % data
    Rate_states_subj_sparsities(i_folder,3) = {Rate_all_states(1,2:end)}; % title
        
    %Rate_states =  mean(Rate_subj); % group level results
    Rate_states =  Rate_subj;
    Rate_all_states(i_folder+1,2:end) = num2cell(Rate_states);
    Rate_all_states(i_folder+1,1) = states(i_folder);
    
    Rate_states_subj(i_folder,1) = states(i_folder);
    Rate_states_subj(i_folder,2) = {Rate_subj};
     end
%end

random_level = [length(loc_c1),length(loc_c2),length(loc_c1c2)]/(length(loc_c1c2) + length(loc_c2) + length(loc_c1));

random_level
Rate_all_states
end
%save(fullfile(out,'ConnectionRates.mat'),'Rate_all_states','random_level')